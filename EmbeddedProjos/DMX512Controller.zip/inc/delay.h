/*
 * delay.h
 *
 *  Created on: Dec 31, 2016
 *      Author: salsiederja
 */

#ifndef DELAY_H_
#define DELAY_H_

void delay(int ms);


#endif /* DELAY_H_ */
