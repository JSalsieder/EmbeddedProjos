/*
 * DMX_COMM.h
 *
 *  Created on: Feb 7, 2017
 *      Author: salsiederja
 */

#ifndef DMX_COMM_H_
#define DMX_COMM_H_

#include "DMX512_Universe.h"
#include "DS75176B.h"
#include "inttypes.h"

#include <stdlib.h>


DMX512* COMM_INIT();



#endif /* DMX_COMM_H_ */
